import os
import logging
import pandas as pd
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from transformers import pipeline
import gradio as gr
from openai import OpenAI
import openai



# Logging setup
logging.basicConfig(level=logging.INFO)

# === Retriever ===
class Retriever:
    def __init__(self, data_path):
        self.documents = []
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.index_path = "index.faiss"
        self._load_data(data_path)

        if os.path.exists(self.index_path):
            logging.info("Loading existing FAISS index...")
            self.index = faiss.read_index(self.index_path)
        else:
            logging.info("Building new FAISS index...")
            self._build_index()
            faiss.write_index(self.index, self.index_path)

    def _load_data(self, path):
        df = pd.read_csv(path).fillna("NA")
        df.columns = df.columns.str.strip()
        for _, row in df.iterrows():
            text = f"""
            Applicant ID: {row['Loan_ID']}
            Gender: {row['Gender']}
            Married: {row['Married']}
            Dependents: {row['Dependents']}
            Education: {row['Education']}
            Self_Employed: {row['Self_Employed']}
            ApplicantIncome: {row['ApplicantIncome']}
            CoapplicantIncome: {row['CoapplicantIncome']}
            LoanAmount: {row['LoanAmount']}
            Loan_Amount_Term: {row['Loan_Amount_Term']}
            Credit_History: {row['Credit_History']}
            Property_Area: {row['Property_Area']}
            Loan_Status: {row['Loan_Status']}
            """
            self.documents.append(text.lower().strip())

    def _build_index(self):
        self.embeddings = self.model.encode(self.documents)
        dim = self.embeddings[0].shape[0]
        self.index = faiss.IndexFlatL2(dim)
        self.index.add(np.array(self.embeddings))

    def retrieve(self, query, top_k=5):
        query_vec = self.model.encode([query])
        _, indices = self.index.search(query_vec, top_k)
        return [self.documents[i] for i in indices[0]]

# === Generator ===
class Generator:
    def __init__(self, use_openai=False, openai_key="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"):
        self.use_openai = use_openai
        if use_openai:
            openai.api_key = "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"
            openai.api_base = "https://openrouter.ai/api/v1"  # OpenRouter base
            self.openai = openai
        else:
            self.model = pipeline("text-generation", model="google/flan-t5-small")

    def generate(self, context, query):
        if not context.strip():
            return "❌ Sorry, no relevant data found."

        prompt = f"""
        You are a helpful assistant trained on loan approval data.
        Answer the user's question truthfully based on the context below.

        Context:
        {context}

        Question: {query}
        Answer:
        """

        if self.use_openai:
            client = OpenAI(
                api_key="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",
                base_url="https://openrouter.ai/api/v1"
            )

            response = client.chat.completions.create(
                model="mistralai/mistral-7b-instruct",
                messages=[{"role": "user", "content": prompt}]
            )

            return response.choices[0].message.content.strip()
        else:
            output = self.model(prompt, max_length=256, do_sample=True)
            return output[0]["generated_text"].split("Answer:")[-1].strip()

# === Gradio UI ===
retriever = Retriever("Training Dataset.csv")
generator = Generator(use_openai=True, openai_key="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")  # Replace with your key

def answer_query(query):
    context = "\n".join(retriever.retrieve(query))
    return generator.generate(context, query)

iface = gr.Interface(fn=answer_query, inputs="text", outputs="text",
                     title="📊 Loan Approval RAG Chatbot (OpenRouter)",
                     description="Ask questions based on loan application data using Mistral via OpenRouter.")

if __name__ == '__main__':
    iface.launch()
